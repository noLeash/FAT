import { useState, useEffect } from "react";
import { Form, Button, Message, Input } from "rsuite";
import axios from "axios";
import { Card } from "./card"; // Import Card with Markdown support
import MarkdownFetcher from "./MarkdownFetcher"; // Import MarkdownFetcher
import ErrorBoundary from "../../api/ErrorBoundary";

const DynamicForm = ({ schema }) => {
  // ✅ Ensure schema is valid
  if (!schema || !schema.fields || !Array.isArray(schema.fields)) {
    console.error("Error: Invalid schema format", schema);
    return <p>Error: Invalid schema format.</p>;
  }

  const [formData, setFormData] = useState({});
  const [submitting, setSubmitting] = useState(false); // ✅ Fixed State Initialization
  const [response, setResponse] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);
  const [markdownFile, setMarkdownFile] = useState(null); // ✅ Track markdown file

  useEffect(() => {
    console.log("DynamicForm received schema:", schema);
  }, [schema]);

  const handleChange = (value, field) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    setResponse(null);
    setErrorMessage(null);
    setMarkdownFile(null); // ✅ Reset markdown file on new submission

    try {
      if (!schema.method) throw new Error("Method is missing in schema.");

      const payload = {
        method: schema.method,
        data: formData
      };

      console.log("Submitting Data:", payload);

      const response = await axios.post(`${import.meta.env.VITE_API_BASE_URL}/api/process`, payload);
      setResponse(response.data);

      // ✅ Check if response includes markdown
      if (response.data.markdown) {
        setMarkdownFile(response.data.markdown);
      }
    } catch (error) {
      console.error("Error processing form:", error);
      setErrorMessage(error.response?.data?.detail || error.message || "Error submitting form.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <ErrorBoundary> {/* ✅ Wrap the entire component in ErrorBoundary */}
      <Form>
        {schema.fields.map((field) => (
          <Form.Group key={field.name}>
            <Form.ControlLabel>{field.label}</Form.ControlLabel>

            {field.type === "markdown" ? (
              <Input
                as="textarea"
                rows={5}
                placeholder="Enter markdown content"
                onChange={(value) => handleChange(value, field.name)}
              />
            ) : (
              <Form.Control
                name={field.name}
                type={field.type || "text"}
                onChange={(value) => handleChange(value, field.name)}
              />
            )}
          </Form.Group>
        ))}

        <Button appearance="primary" onClick={handleSubmit} disabled={submitting}>
          {submitting ? "Submitting..." : "Submit"}
        </Button>

        {/* ✅ Display Markdown File in Card if Available */}
        {markdownFile && (
          <Card title="Markdown Response" markdownFile={markdownFile} />
        )}

        {/* ✅ Display API Response */}
        {response && !markdownFile && (
          <Card title="Response" isMarkdown={true}>
            {response.message}
          </Card>
        )}

        {/* ✅ Display Error Message */}
        {errorMessage && (
          <Message type="error" className="mt-2">
            {errorMessage}
          </Message>
        )}
      </Form>
    </ErrorBoundary>
  );
};

export default DynamicForm;
