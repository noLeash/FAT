import React from "react";
import { Card as RsCard } from "rsuite"; 
import MarkdownViewer from "./MarkdownViewer"; 
import MarkdownFetcher from "./MarkdownFetcher"; // Import MarkdownFetcher

const CardContent = ({ children, isMarkdown = false, markdownFile }) => {
  return (
    <div className="card-content">
      {markdownFile ? (
        <MarkdownFetcher filename={markdownFile} />
      ) : isMarkdown ? (
        <MarkdownViewer content={children} />
      ) : (
        children
      )}
    </div>
  );
};

const Card = ({ title, children, footer, isMarkdown = false, markdownFile }) => {
  return (
    <div>
      <RsCard bordered style={{ width: 300 }}>
        {title && <RsCard.Header>{title}</RsCard.Header>}
        <RsCard.Body>
          <CardContent isMarkdown={isMarkdown} markdownFile={markdownFile}>
            {children}
          </CardContent> 
        </RsCard.Body>
        {footer && <RsCard.Footer>{footer}</RsCard.Footer>}
      </RsCard>
    </div>
  );
};

export { Card, CardContent };
