import { useState, useEffect } from "react";
import axios from "axios";
import MarkdownViewer from "./MarkdownViewer"; 

const MarkdownFetcher = ({ filename }) => {
  const [content, setContent] = useState("");
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!filename) {
      console.warn("MarkdownFetcher: No filename provided.");
      return;
    }

    const fetchMarkdown = async () => {
      try {
        console.log(`Fetching markdown: ${filename}`); // Debugging
        const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/markdown/${filename}`);

        if (!response.data || !response.data.content) {
          throw new Error("Markdown content is missing in API response");
        }
        
        setContent(response.data.content);
      } catch (err) {
        console.error("Error fetching markdown:", err);
        setError("Markdown file not found.");
      }
    };

    fetchMarkdown();
  }, [filename]);

  if (error) return <p className="text-red-500">{error}</p>;

  return <MarkdownViewer content={content} />;
};

export default MarkdownFetcher;
