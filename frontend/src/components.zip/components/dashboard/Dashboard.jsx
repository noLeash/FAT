import { useState } from "react";
import SelectFunction from "./SelectFunction";
import MethodBox from "./MethodBox";

const Dashboard = ({ methods }) => {
  const [selectedMethod, setSelectedMethod] = useState(null);

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      
      <SelectFunction onSelect={(method) => setSelectedMethod(method)}>
        {methods.map((item) => (
          <Dropdown.Item key={item.method} onClick={() => setSelectedMethod(item.method)}>
            {item.title}
          </Dropdown.Item>
        ))}
      </SelectFunction>
      
      {selectedMethod && <MethodBox method={selectedMethod} />}
    </div>
  );
};

export default Dashboard;
