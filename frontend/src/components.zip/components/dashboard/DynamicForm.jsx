import { useState } from "react";
import { Form, FormGroup, FormControl, ControlLabel, Button } from "rsuite";

const DynamicForm = ({ schema }) => {
  const [formData, setFormData] = useState({});

  const handleChange = (value, field) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    console.log("Submitted Data:", formData);
  };

  return (
    <Form fluid>
      {schema?.fields?.map((field) => (
        <FormGroup key={field.name}>
          <ControlLabel>{field.label}</ControlLabel>
          <FormControl
            name={field.name}
            type={field.type || "text"}
            onChange={(value) => handleChange(value, field.name)}
          />
        </FormGroup>
      ))}
      <Button appearance="primary" onClick={handleSubmit}>
        Submit
      </Button>
    </Form>
  );
};

export default DynamicForm;
