import React, { useState, useEffect } from "react";
import { Dropdown } from "rsuite";
import axios from "axios";

const minWidth = 120;

const SelectFunction = ({ onSelect }) => {
    const [menuData, setMenuData] = useState([]);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/functions/listof`);
                console.log("API Response:", response.data);
                setMenuData(response.data);
            } catch (err) {
                setError("Failed to fetch data.");
                console.error("Error fetching data:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    // Recursive function to render nested dropdown items
    const renderMenuItems = (items = []) => {
        return items.map((item) =>
            item.children ? (
                <Dropdown.Menu key={item.id} title={item.title} style={{ minWidth }}>
                    {renderMenuItems(item.children)}
                </Dropdown.Menu>
            ) : (
                <Dropdown.Item key={item.method} onClick={() => onSelect(item.method)}>
                    {item.title}
                </Dropdown.Item>
            )
        );
    };

    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    return (
        <Dropdown title="Select Function" placement="bottomStart">
            {renderMenuItems(menuData)}
        </Dropdown>
    );
};

export default SelectFunction;
