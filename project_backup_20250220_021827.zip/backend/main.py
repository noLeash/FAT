from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes.methods import methods

app = FastAPI()

app.include_router(methods)



# CORS setup to allow frontend to talk to backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change this to frontend URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/data")
async def get_data():
    return {"message": "Hello from FastAPI!"}
