import os
import json
from fastapi import APIRouter


methods = APIRouter()


from pydantic import BaseModel
from typing import List


class NumberInput(BaseModel):
    numbers: str  # Accepts a string (e.g., "1,2,3,4")


# Load JSON Function Structure Dictionary
def load_json_data():
    file_path = os.path.join(os.path.dirname(__file__), "function_dictionary.json")
    with open(file_path, "r") as file:
        return json.load(file)
func_dict = load_json_data()
print("JSON FILE:", load_json_data())



@methods.post("/api/parse-numbers")
async def parse_numbers(data: NumberInput):
    try:
        # Split the string into a list of numbers
        number_list = [int(num.strip()) for num in data.numbers.split(",") if num.strip().isdigit()]
        return {"numbers": number_list}
    except ValueError:
        return {"error": "Invalid input, please provide a comma-separated list of numbers"}



@methods.get("/api/functions")
async def get_functions():
    func_dict = load_json_data()
    return func_dict


@methods.get("/api/formula-schemas")
async def get_functions():
    return {
        "formulaA": {
            "name": "Formula A",
            "fields": [
                { "name": "input1", "label": "First Input", "type": "number", "placeholder": "Enter value", "required": "true" },
                { "name": "dateInput", "label": "Select Date", "type": "date", "required": "true" },
                { 
                    "name": "dataSource", 
                    "label": "Select Data Source", 
                    "type": "select", 
                    "options": ["Option 1", "Option 2", "Option 3"],
                    "required": "true"
                },
                {
                    "name": "marketData",
                    "label": "Fetch Market Data",
                    "type": "data-source",
                    "subfields": [
                        { "name": "ticker", "label": "Stock Ticker", "type": "text", "placeholder": "AAPL", "required": "true" },
                        { "name": "startDate", "label": "Start Date", "type": "date", "required": "true" },
                        { "name": "endDate", "label": "End Date", "type": "date", "required": "true" }
                    ],
                    "source": "/api/market-data"
                }
            ],
            "endpoint": "/api/formulaA"
        }
    }

