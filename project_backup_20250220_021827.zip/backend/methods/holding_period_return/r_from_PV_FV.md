where

$R$ = Holding Period Return

$PV$ = Present Value

$FV$ = Future Value

$R = \frac{FV - PV}{PV}$
