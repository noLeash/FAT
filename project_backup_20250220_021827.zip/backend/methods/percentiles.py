

class percentiles:
    def __init__(self):
        pass

    def quartile(self, list):
        
        return
    
    def quintiles(self, list):

        return
    
    def deciles(self, list):

        return
    
    def quartile(self, list):

        return