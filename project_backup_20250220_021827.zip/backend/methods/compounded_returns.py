def test():
    pass


class compounded_returns:
    def __init__(self):
        pass


