The **geometric** mean is the $n$th root of the product of all the values
$$
\sqrt[n]{\sum x_t} = \sqrt[n] {x_{t=0} \times x_{t=1} \times x_{t=2}}
$$