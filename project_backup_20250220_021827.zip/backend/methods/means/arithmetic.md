The **arithmetic** mean is the sum of the values divided by the total number of values.
$$
\bar X = \frac{\sum n}{n}
$$