import React, { useState, useEffect } from "react";
import axios from "axios";
import { Input, DatePicker, SelectPicker, Button } from "rsuite";
import "rsuite/dist/rsuite.min.css"; // Import RSuite styles

const WorkBox = ({ title, schema }) => {
    const [formData, setFormData] = useState(
        schema.fields.reduce((acc, field) => {
            if (field.type === "data-source") {
                acc[field.name] = field.subfields.reduce((subAcc, sub) => {
                    subAcc[sub.name] = "";
                    return subAcc;
                }, {});
            } else {
                acc[field.name] = "";
            }
            return acc;
        }, {})
    );

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [dynamicOptions, setDynamicOptions] = useState({});

    // Fetch dynamic data for select options
    useEffect(() => {
        const fetchDynamicOptions = async () => {
            for (const field of schema.fields) {
                if (field.type === "select" && field.source) {
                    try {
                        const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}${field.source}`);
                        setDynamicOptions((prev) => ({ ...prev, [field.name]: response.data.map(opt => ({ label: opt, value: opt })) }));
                    } catch (err) {
                        console.error(`Error fetching ${field.name} options:`, err);
                    }
                }
            }
        };

        fetchDynamicOptions();
    }, [schema.fields]);

    const handleChange = (value, field) => {
        if (field.type === "data-source") {
            setFormData((prev) => ({
                ...prev,
                [field.name]: {
                    ...prev[field.name],
                    [field.name]: value,
                },
            }));
        } else {
            setFormData((prev) => ({ ...prev, [field.name]: value }));
        }
    };

    const handleSubmit = async () => {
        setLoading(true);
        try {
            await axios.post(`${import.meta.env.VITE_API_BASE_URL}${schema.endpoint}`, formData);
            alert("Submission successful!");
        } catch (err) {
            setError("Submission failed.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ border: "1px solid #ddd", padding: "10px", marginBottom: "10px" }}>
            <h3>{title}</h3>
            {schema.fields.map((field) => (
                <div key={field.name} style={{ marginBottom: "10px" }}>
                    <label>{field.label}:</label>
                    
                    {/* Text, Number, and Date Inputs */}
                    {(field.type === "text" || field.type === "number") && (
                        <Input
                            type={field.type}
                            name={field.name}
                            value={formData[field.name]}
                            onChange={(value) => handleChange(value, field)}
                            placeholder={field.placeholder}
                            required={field.required}
                        />
                    )}

                    {/* Date Picker */}
                    {field.type === "date" && (
                        <DatePicker
                            oneTap
                            format="YYYY-MM-DD"
                            value={formData[field.name] ? new Date(formData[field.name]) : null}
                            onChange={(value) => handleChange(value?.toISOString().split("T")[0], field)}
                            placeholder={field.placeholder || "Select a date"}
                        />
                    )}

                    {/* Select Dropdown */}
                    {field.type === "select" && (
                        <SelectPicker
                            data={field.options ? field.options.map(opt => ({ label: opt, value: opt })) : dynamicOptions[field.name] || []}
                            searchable={true}
                            cleanable={false}
                            placeholder={field.placeholder || "Select an option"}
                            value={formData[field.name]}
                            onChange={(value) => handleChange(value, field)}
                        />
                    )}

                    {/* Data Source (Ticker + Start/End Date) */}
                    {field.type === "data-source" && (
                        <div>
                            {field.subfields.map((sub) => (
                                <div key={sub.name} style={{ marginBottom: "5px" }}>
                                    <label>{sub.label}:</label>
                                    {sub.type === "date" ? (
                                        <DatePicker
                                            oneTap
                                            format="YYYY-MM-DD"
                                            value={formData[field.name][sub.name] ? new Date(formData[field.name][sub.name]) : null}
                                            onChange={(value) => handleChange(value?.toISOString().split("T")[0], { ...sub, name: `${field.name}.${sub.name}` })}
                                            placeholder={sub.placeholder || "Select a date"}
                                        />
                                    ) : (
                                        <Input
                                            type={sub.type}
                                            name={sub.name}
                                            value={formData[field.name][sub.name]}
                                            onChange={(value) => handleChange(value, { ...sub, name: `${field.name}.${sub.name}` })}
                                            placeholder={sub.placeholder}
                                            required={sub.required}
                                        />
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            ))}
            {error && <p style={{ color: "red" }}>{error}</p>}
            <Button appearance="primary" onClick={handleSubmit} loading={loading}>
                Submit
            </Button>
        </div>
    );
};

export default WorkBox;
