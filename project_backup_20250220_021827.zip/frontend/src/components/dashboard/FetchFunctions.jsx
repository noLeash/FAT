import React, { useState, useEffect } from "react";
import axios from "axios";
import WorkBox from "./WorkBox";

const FetchFunctions = () => {
    const [schemas, setSchemas] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchSchemas = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_API_BASE_URL}/api/formula-schemas`);
                setSchemas(response.data); // Store schema object
            } catch (err) {
                setError("Failed to load formula schemas.");
                console.error("Error:", err);
            } finally {
                setLoading(false);
            }
        };

        fetchSchemas();
    }, []);

    return (
        <div>
            <h2>Available Function Groups</h2>
            {loading && <p>Loading...</p>}
            {error && <p style={{ color: "red" }}>{error}</p>}
            <ul>
                {Object.keys(schemas).map((funcId) => (
                    <WorkBox key={funcId} title={schemas[funcId].name} schema={schemas[funcId]} />
                ))}
            </ul>
        </div>
    );
};

export default FetchFunctions;
