import React, { useState } from "react";

const InputTest = ({ functionName, funcId }) => {
    const [inputValue, setInputValue] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        alert(`Submitting "${inputValue}" for function "${functionName}" (${funcId})`);
    };

    return (
        <div>
            <p>Provide input for <strong>{functionName}</strong>:</p>
            <form onSubmit={handleSubmit}>
                <input 
                    type="text" 
                    value={inputValue} 
                    onChange={(e) => setInputValue(e.target.value)} 
                    placeholder="Enter value" 
                    style={{ padding: "5px", marginRight: "5px" }}
                />
                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default InputTest;
