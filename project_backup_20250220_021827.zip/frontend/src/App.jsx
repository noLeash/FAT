import { useState } from 'react'
import reactLogo from './assets/react.svg'
import './App.css'
import FetchData from './components/dashboard/Dashboard'
import FetchFunctions from './components/dashboard/FetchFunctions'


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <FetchData />
        <FetchFunctions />
      </div>
    </>
  )
}

export default App
